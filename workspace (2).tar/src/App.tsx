import { useState, useEffect, useRef, useCallback } from 'react'

interface Star {
  x: number
  y: number
  size: number
  speed: number
  opacity: number
  twinkle: number
}

interface Bullet {
  x: number
  y: number
  speed: number
}

interface Asteroid {
  x: number
  y: number
  size: number
  speed: number
  rotation: number
  rotationSpeed: number
  vertices: number[]
  color1: string
  color2: string
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
  size: number
}

interface PowerUp {
  x: number
  y: number
  speed: number
  type: 'shield' | 'rapid' | 'multi'
  size: number
  pulse: number
}

interface Enemy {
  x: number
  y: number
  width: number
  height: number
  hp: number
  maxHp: number
  speed: number
  type: 'scout' | 'fighter' | 'heavy'
  shootTimer: number
  shootCooldown: number
  movePattern: 'straight' | 'zigzag' | 'sine'
  moveOffset: number
  color: string
  points: number
}

interface EnemyBullet {
  x: number
  y: number
  vx: number
  vy: number
}

type GameState = 'menu' | 'playing' | 'gameover' | 'win'

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<GameState>('menu')
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(() => parseInt(localStorage.getItem('spaceHighScore') || '0'))
  const [lives, setLives] = useState(3)
  const [level, setLevel] = useState(1)
  const [powerUp, setPowerUp] = useState<string | null>(null)
  const [combo, setCombo] = useState(0)
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set())
  const [distance, setDistance] = useState(0)

  const gameRef = useRef({
    player: { x: 0, y: 0, width: 40, height: 40, shield: false, rapid: false, multi: false },
    bullets: [] as Bullet[],
    asteroids: [] as Asteroid[],
    stars: [] as Star[],
    particles: [] as Particle[],
    powerUps: [] as PowerUp[],
    enemies: [] as Enemy[],
    enemyBullets: [] as EnemyBullet[],
    keys: {} as Record<string, boolean>,
    score: 0,
    lives: 3,
    level: 1,
    combo: 0,
    comboTimer: 0,
    lastShot: 0,
    shootCooldown: 200,
    animationId: 0,
    spawnTimer: 0,
    powerUpTimer: 0,
    enemySpawnTimer: 0,
    screenShake: 0,
    invincible: 0,
    distance: 0,
    distanceTimer: 0,
    earthY: 0,
    moonY: 0,
    time: 0,
  })

  const initStars = useCallback((width: number, height: number) => {
    const stars: Star[] = []
    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2.5 + 0.3,
        speed: Math.random() * 1.5 + 0.3,
        opacity: Math.random() * 0.8 + 0.2,
        twinkle: Math.random() * Math.PI * 2,
      })
    }
    return stars
  }, [])

  const createAsteroid = useCallback((width: number): Asteroid => {
    const size = Math.random() * 35 + 18
    const vertices: number[] = []
    const numVertices = Math.floor(Math.random() * 4) + 7
    for (let i = 0; i < numVertices; i++) {
      vertices.push(size * (0.6 + Math.random() * 0.7))
    }
    const colors = [
      ['#8B7355', '#5C4033'],
      ['#A0522D', '#6B3A2A'],
      ['#696969', '#3D3D3D'],
      ['#7B6B5D', '#4A3C30'],
    ]
    const c = colors[Math.floor(Math.random() * colors.length)]
    return {
      x: Math.random() * (width - size * 2) + size,
      y: -size * 2,
      size,
      speed: Math.random() * 2 + 1 + gameRef.current.level * 0.3,
      rotation: 0,
      rotationSpeed: (Math.random() - 0.5) * 0.04,
      vertices,
      color1: c[0],
      color2: c[1],
    }
  }, [])

  const createEnemy = useCallback((width: number, level: number): Enemy => {
    const types = [
      { type: 'scout' as const, hp: 1, speed: 2.5, cooldown: 120, color: '#22d3ee', points: 25, size: 25 },
      { type: 'fighter' as const, hp: 3, speed: 1.8, cooldown: 80, color: '#f97316', points: 50, size: 32 },
      { type: 'heavy' as const, hp: 7, speed: 1.0, cooldown: 100, color: '#ef4444', points: 100, size: 45 },
    ]
    let typeIndex = 0
    const roll = Math.random()
    if (level >= 3 && roll < 0.2) typeIndex = 2
    else if (level >= 2 && roll < 0.4) typeIndex = 1
    else if (roll < 0.5) typeIndex = 1
    const t = types[typeIndex]
    const patterns: Enemy['movePattern'][] = ['straight', 'zigzag', 'sine']
    return {
      x: Math.random() * (width - 100) + 50,
      y: -50,
      width: t.size,
      height: t.size,
      hp: t.hp + Math.floor(level / 3),
      maxHp: t.hp + Math.floor(level / 3),
      speed: t.speed + level * 0.1,
      type: t.type,
      shootTimer: Math.random() * t.cooldown,
      shootCooldown: t.cooldown,
      movePattern: patterns[Math.floor(Math.random() * patterns.length)],
      moveOffset: Math.random() * Math.PI * 2,
      color: t.color,
      points: t.points,
    }
  }, [])

  const createParticles = useCallback((x: number, y: number, color: string, count: number) => {
    const particles: Particle[] = []
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5
      const speed = Math.random() * 4 + 2
      particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        color,
        size: Math.random() * 3 + 1,
      })
    }
    return particles
  }, [])

  const shoot = useCallback(() => {
    const game = gameRef.current
    const now = Date.now()
    const cooldown = game.player.rapid ? 100 : game.shootCooldown
    if (now - game.lastShot < cooldown) return
    game.lastShot = now
    if (game.player.multi) {
      game.bullets.push(
        { x: game.player.x, y: game.player.y - 20, speed: 9 },
        { x: game.player.x - 15, y: game.player.y - 15, speed: 9 },
        { x: game.player.x + 15, y: game.player.y - 15, speed: 9 }
      )
    } else {
      game.bullets.push({ x: game.player.x, y: game.player.y - 20, speed: 9 })
    }
  }, [])

  const startGame = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const game = gameRef.current
    game.player = { x: canvas.width / 2, y: canvas.height - 80, width: 40, height: 40, shield: false, rapid: false, multi: false }
    game.bullets = []
    game.asteroids = []
    game.particles = []
    game.powerUps = []
    game.enemies = []
    game.enemyBullets = []
    game.stars = initStars(canvas.width, canvas.height)
    game.score = 0
    game.lives = 3
    game.level = 1
    game.combo = 0
    game.comboTimer = 0
    game.lastShot = 0
    game.spawnTimer = 0
    game.powerUpTimer = 0
    game.enemySpawnTimer = 0
    game.screenShake = 0
    game.invincible = 0
    game.distance = 0
    game.distanceTimer = 0
    game.earthY = canvas.height + 100
    game.moonY = -200
    game.time = 0
    setScore(0)
    setLives(3)
    setLevel(1)
    setCombo(0)
    setPowerUp(null)
    setDistance(0)
    setGameState('playing')
  }, [initStars])

  // ===================== GAME LOOP =====================
  const gameLoop = useCallback(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return
    const game = gameRef.current
    const { player, bullets, asteroids, stars, particles, powerUps, enemies, keys } = game

    game.time++

    // === DISTANCE PROGRESS ===
    game.distanceTimer++
    if (game.distanceTimer >= 2) {
      game.distanceTimer = 0
      game.distance = Math.min(100, game.distance + 0.08 + game.level * 0.01)
      setDistance(Math.floor(game.distance))
      if (game.distance >= 100) {
        if (game.score > highScore) {
          setHighScore(game.score)
          localStorage.setItem('spaceHighScore', game.score.toString())
        }
        setGameState('win')
        return
      }
    }

    // Earth rises from bottom, Moon descends from top
    game.earthY = canvas.height + 100 - game.distance * 5
    game.moonY = -200 + game.distance * 4

    // === BACKGROUND ===
    // Gradient changes with distance
    const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height)
    if (game.distance < 30) {
      // Near Earth — blue atmosphere
      const t = game.distance / 30
      bgGrad.addColorStop(0, `rgb(${Math.floor(5 + t * 5)}, ${Math.floor(5 + t * 5)}, ${Math.floor(30 + t * 10)})`)
      bgGrad.addColorStop(0.5, `rgb(${Math.floor(10 + t * 10)}, ${Math.floor(10 + t * 5)}, ${Math.floor(40 + t * 20)})`)
      bgGrad.addColorStop(1, `rgb(${Math.floor(20 + (1 - t) * 40)}, ${Math.floor(30 + (1 - t) * 60)}, ${Math.floor(60 + (1 - t) * 80)})`)
    } else if (game.distance < 70) {
      // Deep space
      bgGrad.addColorStop(0, '#050510')
      bgGrad.addColorStop(0.5, '#0a0a20')
      bgGrad.addColorStop(1, '#0f0f2a')
    } else {
      // Near Moon — greyish
      const t = (game.distance - 70) / 30
      bgGrad.addColorStop(0, `rgb(${Math.floor(5 + t * 20)}, ${Math.floor(5 + t * 18)}, ${Math.floor(16 + t * 15)})`)
      bgGrad.addColorStop(0.5, `rgb(${Math.floor(10 + t * 15)}, ${Math.floor(10 + t * 13)}, ${Math.floor(32 + t * 10)})`)
      bgGrad.addColorStop(1, `rgb(${Math.floor(15 + t * 25)}, ${Math.floor(15 + t * 22)}, ${Math.floor(42 + t * 15)})`)
    }
    ctx.fillStyle = bgGrad
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Screen shake
    if (game.screenShake > 0) {
      ctx.save()
      ctx.translate((Math.random() - 0.5) * game.screenShake, (Math.random() - 0.5) * game.screenShake)
      game.screenShake *= 0.9
      if (game.screenShake < 0.5) game.screenShake = 0
    }

    // === EARTH (bottom) ===
    if (game.earthY < canvas.height + 200) {
      const earthRadius = 600
      const earthCenterX = canvas.width / 2
      const earthCenterY = game.earthY + earthRadius - 50
      const earthGrad = ctx.createRadialGradient(earthCenterX, earthCenterY, earthRadius * 0.3, earthCenterX, earthCenterY, earthRadius)
      earthGrad.addColorStop(0, '#4a9eff')
      earthGrad.addColorStop(0.4, '#2563eb')
      earthGrad.addColorStop(0.7, '#1d4ed8')
      earthGrad.addColorStop(1, '#0c2d6b')
      ctx.fillStyle = earthGrad
      ctx.beginPath()
      ctx.arc(earthCenterX, earthCenterY, earthRadius, 0, Math.PI * 2)
      ctx.fill()
      // Atmosphere glow
      ctx.strokeStyle = 'rgba(100, 180, 255, 0.3)'
      ctx.lineWidth = 8
      ctx.beginPath()
      ctx.arc(earthCenterX, earthCenterY, earthRadius + 5, 0, Math.PI * 2)
      ctx.stroke()
      // Continents
      ctx.fillStyle = 'rgba(34, 197, 94, 0.4)'
      for (let i = 0; i < 5; i++) {
        const cx = earthCenterX + Math.cos(i * 1.3 + game.time * 0.001) * earthRadius * 0.5
        const cy = earthCenterY + Math.sin(i * 1.7 + game.time * 0.001) * earthRadius * 0.3
        ctx.beginPath()
        ctx.ellipse(cx, cy, 60 + i * 20, 40 + i * 10, i * 0.5, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    // === MOON (top) ===
    if (game.moonY > -300) {
      const moonRadius = 300
      const moonCenterX = canvas.width / 2
      const moonCenterY = game.moonY + moonRadius - 50
      const moonGrad = ctx.createRadialGradient(moonCenterX - 50, moonCenterY - 50, moonRadius * 0.1, moonCenterX, moonCenterY, moonRadius)
      moonGrad.addColorStop(0, '#e5e5e5')
      moonGrad.addColorStop(0.5, '#b0b0b0')
      moonGrad.addColorStop(1, '#707070')
      ctx.fillStyle = moonGrad
      ctx.beginPath()
      ctx.arc(moonCenterX, moonCenterY, moonRadius, 0, Math.PI * 2)
      ctx.fill()
      // Craters
      ctx.fillStyle = 'rgba(80, 80, 80, 0.4)'
      const craters = [[0.2, 0.3, 30], [-0.3, 0.1, 20], [0.1, -0.2, 25], [-0.1, 0.4, 15], [0.35, -0.1, 18]]
      craters.forEach(([cx, cy, r]) => {
        ctx.beginPath()
        ctx.arc(moonCenterX + cx * moonRadius, moonCenterY + cy * moonRadius, r, 0, Math.PI * 2)
        ctx.fill()
      })
      // Finish flag on moon
      if (game.distance > 80) {
        const flagX = moonCenterX
        const flagY = moonCenterY + moonRadius - 20
        ctx.fillStyle = '#fff'
        ctx.fillRect(flagX - 1, flagY - 40, 2, 40)
        ctx.fillStyle = '#ef4444'
        ctx.fillRect(flagX + 1, flagY - 40, 20, 12)
        ctx.fillStyle = '#fff'
        ctx.font = '8px Arial'
        ctx.fillText('🏁', flagX + 3, flagY - 31)
      }
    }

    // === STARS ===
    stars.forEach((star) => {
      star.y += star.speed
      star.twinkle += 0.03
      if (star.y > canvas.height) {
        star.y = 0
        star.x = Math.random() * canvas.width
      }
      const alpha = star.opacity * (0.7 + Math.sin(star.twinkle) * 0.3)
      ctx.beginPath()
      ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`
      ctx.fill()
    })

    // Nebula clouds
    if (game.distance > 20 && game.distance < 80) {
      ctx.globalAlpha = 0.05
      for (let i = 0; i < 3; i++) {
        const nx = (canvas.width * 0.3 + i * canvas.width * 0.2 + game.time * 0.1) % (canvas.width + 200) - 100
        const ny = canvas.height * 0.3 + Math.sin(game.time * 0.005 + i) * 100
        const nGrad = ctx.createRadialGradient(nx, ny, 0, nx, ny, 150)
        nGrad.addColorStop(0, i % 2 === 0 ? '#a855f7' : '#3b82f6')
        nGrad.addColorStop(1, 'transparent')
        ctx.fillStyle = nGrad
        ctx.fillRect(nx - 150, ny - 150, 300, 300)
      }
      ctx.globalAlpha = 1
    }

    // === PLAYER MOVEMENT ===
    const speed = 6
    if (keys['a'] || keys['arrowleft']) player.x -= speed
    if (keys['d'] || keys['arrowright']) player.x += speed
    if (keys['w'] || keys['arrowup']) player.y -= speed
    if (keys['s'] || keys['arrowdown']) player.y += speed
    player.x = Math.max(player.width / 2, Math.min(canvas.width - player.width / 2, player.x))
    player.y = Math.max(player.height / 2, Math.min(canvas.height - player.height / 2, player.y))

    // Shoot on touch hold
    if (touchRef.current) shoot()

    // === DRAW PLAYER SHIP ===
    const invFlash = game.invincible > 0 && Math.floor(game.time / 5) % 2 === 0
    if (!invFlash) {
      ctx.save()
      ctx.translate(player.x, player.y)

      // Engine glow
      ctx.shadowColor = '#f97316'
      ctx.shadowBlur = 20
      const flameH = 12 + Math.sin(game.time * 0.3) * 5
      const flameGrad = ctx.createLinearGradient(0, 16, 0, 16 + flameH)
      flameGrad.addColorStop(0, '#fbbf24')
      flameGrad.addColorStop(0.5, '#f97316')
      flameGrad.addColorStop(1, 'rgba(239, 68, 68, 0)')
      ctx.fillStyle = flameGrad
      ctx.beginPath()
      ctx.moveTo(-7, 16)
      ctx.quadraticCurveTo(-3, 16 + flameH * 0.6, 0, 16 + flameH)
      ctx.quadraticCurveTo(3, 16 + flameH * 0.6, 7, 16)
      ctx.closePath()
      ctx.fill()

      // Side flames
      ctx.fillStyle = '#f9731680'
      ctx.beginPath()
      ctx.moveTo(-12, 14)
      ctx.quadraticCurveTo(-10, 14 + flameH * 0.4, -8, 14)
      ctx.closePath()
      ctx.fill()
      ctx.beginPath()
      ctx.moveTo(12, 14)
      ctx.quadraticCurveTo(10, 14 + flameH * 0.4, 8, 14)
      ctx.closePath()
      ctx.fill()

      ctx.shadowBlur = 0

      // Ship body — sleek rocket
      const bodyGrad = ctx.createLinearGradient(-15, 0, 15, 0)
      bodyGrad.addColorStop(0, '#6366f1')
      bodyGrad.addColorStop(0.3, '#a855f7')
      bodyGrad.addColorStop(0.7, '#a855f7')
      bodyGrad.addColorStop(1, '#6366f1')
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.moveTo(0, -24)
      ctx.quadraticCurveTo(-6, -18, -10, -5)
      ctx.lineTo(-14, 14)
      ctx.lineTo(-8, 16)
      ctx.lineTo(0, 14)
      ctx.lineTo(8, 16)
      ctx.lineTo(14, 14)
      ctx.lineTo(10, -5)
      ctx.quadraticCurveTo(6, -18, 0, -24)
      ctx.closePath()
      ctx.fill()

      // Wings
      ctx.fillStyle = '#4f46e5'
      ctx.beginPath()
      ctx.moveTo(-10, 5)
      ctx.lineTo(-22, 16)
      ctx.lineTo(-14, 14)
      ctx.closePath()
      ctx.fill()
      ctx.beginPath()
      ctx.moveTo(10, 5)
      ctx.lineTo(22, 16)
      ctx.lineTo(14, 14)
      ctx.closePath()
      ctx.fill()

      // Cockpit
      const cockpitGrad = ctx.createRadialGradient(0, -8, 0, 0, -8, 7)
      cockpitGrad.addColorStop(0, '#93c5fd')
      cockpitGrad.addColorStop(0.7, '#3b82f6')
      cockpitGrad.addColorStop(1, '#1e40af')
      ctx.fillStyle = cockpitGrad
      ctx.beginPath()
      ctx.ellipse(0, -8, 5, 7, 0, 0, Math.PI * 2)
      ctx.fill()
      // Cockpit shine
      ctx.fillStyle = 'rgba(255,255,255,0.4)'
      ctx.beginPath()
      ctx.ellipse(-1.5, -10, 2, 3, -0.3, 0, Math.PI * 2)
      ctx.fill()

      // Shield
      if (player.shield) {
        ctx.strokeStyle = `rgba(96, 165, 250, ${0.5 + Math.sin(game.time * 0.1) * 0.3})`
        ctx.lineWidth = 2
        ctx.setLineDash([5, 5])
        ctx.beginPath()
        ctx.arc(0, 0, 32, 0, Math.PI * 2)
        ctx.stroke()
        ctx.setLineDash([])
      }

      ctx.restore()
    }

    // === BULLETS ===
    for (let i = bullets.length - 1; i >= 0; i--) {
      bullets[i].y -= bullets[i].speed
      if (bullets[i].y < -10) { bullets.splice(i, 1); continue }
      // Laser bullet
      ctx.shadowColor = '#fbbf24'
      ctx.shadowBlur = 12
      const bGrad = ctx.createLinearGradient(bullets[i].x, bullets[i].y - 10, bullets[i].x, bullets[i].y + 10)
      bGrad.addColorStop(0, '#fef3c7')
      bGrad.addColorStop(0.5, '#fbbf24')
      bGrad.addColorStop(1, '#f97316')
      ctx.fillStyle = bGrad
      ctx.beginPath()
      ctx.ellipse(bullets[i].x, bullets[i].y, 2.5, 10, 0, 0, Math.PI * 2)
      ctx.fill()
      // Trail
      ctx.fillStyle = 'rgba(251, 191, 36, 0.3)'
      ctx.beginPath()
      ctx.ellipse(bullets[i].x, bullets[i].y + 12, 1.5, 6, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.shadowBlur = 0
    }

    // === SPAWN ASTEROIDS ===
    game.spawnTimer++
    const spawnRate = Math.max(20, 60 - game.level * 5)
    if (game.spawnTimer >= spawnRate) {
      game.spawnTimer = 0
      game.asteroids.push(createAsteroid(canvas.width))
    }

    // === SPAWN POWER-UPS ===
    game.powerUpTimer++
    if (game.powerUpTimer >= 600) {
      game.powerUpTimer = 0
      const types: ('shield' | 'rapid' | 'multi')[] = ['shield', 'rapid', 'multi']
      powerUps.push({
        x: Math.random() * (canvas.width - 40) + 20,
        y: -20,
        speed: 2,
        type: types[Math.floor(Math.random() * types.length)],
        size: 15,
        pulse: 0,
      })
    }

    // === POWER-UPS ===
    for (let i = powerUps.length - 1; i >= 0; i--) {
      powerUps[i].y += powerUps[i].speed
      powerUps[i].pulse += 0.05
      if (powerUps[i].y > canvas.height + 20) { powerUps.splice(i, 1); continue }
      const colors = { shield: '#60a5fa', rapid: '#fbbf24', multi: '#34d399' }
      const icons = { shield: '🛡️', rapid: '⚡', multi: '✦' }
      ctx.save()
      ctx.translate(powerUps[i].x, powerUps[i].y)
      ctx.shadowColor = colors[powerUps[i].type]
      ctx.shadowBlur = 15 + Math.sin(powerUps[i].pulse) * 5
      ctx.fillStyle = colors[powerUps[i].type] + '40'
      ctx.beginPath()
      ctx.arc(0, 0, powerUps[i].size + Math.sin(powerUps[i].pulse) * 3, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = colors[powerUps[i].type]
      ctx.beginPath()
      ctx.arc(0, 0, powerUps[i].size - 3, 0, Math.PI * 2)
      ctx.fill()
      ctx.font = '14px Arial'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillStyle = '#fff'
      ctx.fillText(icons[powerUps[i].type], 0, 0)
      ctx.restore()
      ctx.shadowBlur = 0
      const dx = powerUps[i].x - player.x
      const dy = powerUps[i].y - player.y
      if (Math.sqrt(dx * dx + dy * dy) < 30) {
        const pu = powerUps[i]
        if (pu.type === 'shield') { player.shield = true; setPowerUp('shield') }
        else if (pu.type === 'rapid') { player.rapid = true; setPowerUp('rapid') }
        else if (pu.type === 'multi') { player.multi = true; setPowerUp('multi') }
        game.particles.push(...createParticles(player.x, player.y, colors[pu.type], 15))
        powerUps.splice(i, 1)
        setTimeout(() => { player.shield = false; player.rapid = false; player.multi = false; setPowerUp(null) }, 8000)
      }
    }

    // === SPAWN ENEMIES === (disabled for now)
    // game.enemySpawnTimer++
    // const enemySpawnRate = Math.max(60, 180 - game.level * 15)
    // if (game.enemySpawnTimer >= enemySpawnRate) {
    //   game.enemySpawnTimer = 0
    //   game.enemies.push(createEnemy(canvas.width, game.level))
    // }

    // === ENEMIES === (disabled - no spawning)
    for (let i = enemies.length - 1; i >= 0; i--) {
      const enemy = enemies[i]
      enemy.moveOffset += 0.03
      if (enemy.movePattern === 'zigzag') enemy.x += Math.sin(enemy.moveOffset * 3) * 2
      else if (enemy.movePattern === 'sine') enemy.x += Math.sin(enemy.moveOffset) * 3
      enemy.y += enemy.speed
      if (enemy.y > canvas.height + 60) { enemies.splice(i, 1); continue }

      // Enemy shooting
      enemy.shootTimer++
      if (enemy.shootTimer >= enemy.shootCooldown && enemy.y > 0 && enemy.y < canvas.height * 0.7) {
        enemy.shootTimer = 0
        const dx = player.x - enemy.x
        const dy = player.y - enemy.y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist > 0) {
          game.enemyBullets.push({ x: enemy.x, y: enemy.y + enemy.height / 2, vx: (dx / dist) * 4, vy: (dy / dist) * 4 })
        }
      }

      // Draw enemy
      ctx.save()
      ctx.translate(enemy.x, enemy.y)
      ctx.shadowColor = enemy.color
      ctx.shadowBlur = 12

      if (enemy.type === 'scout') {
        // UFO-like scout
        ctx.fillStyle = enemy.color
        ctx.beginPath()
        ctx.ellipse(0, 0, enemy.width / 2, enemy.height / 4, 0, 0, Math.PI * 2)
        ctx.fill()
        // Dome
        const domeGrad = ctx.createRadialGradient(0, -5, 0, 0, -5, 10)
        domeGrad.addColorStop(0, '#67e8f9')
        domeGrad.addColorStop(1, '#0e7490')
        ctx.fillStyle = domeGrad
        ctx.beginPath()
        ctx.arc(0, -5, 10, Math.PI, 0)
        ctx.fill()
        // Lights
        for (let l = 0; l < 3; l++) {
          ctx.fillStyle = game.time % 20 < 10 ? '#fbbf24' : '#ef4444'
          ctx.beginPath()
          ctx.arc(-8 + l * 8, 3, 2, 0, Math.PI * 2)
          ctx.fill()
        }
      } else if (enemy.type === 'fighter') {
        // Angular fighter
        const fGrad = ctx.createLinearGradient(0, -enemy.height / 2, 0, enemy.height / 2)
        fGrad.addColorStop(0, '#1f2937')
        fGrad.addColorStop(0.5, enemy.color)
        fGrad.addColorStop(1, '#1f2937')
        ctx.fillStyle = fGrad
        ctx.beginPath()
        ctx.moveTo(0, enemy.height / 2)
        ctx.lineTo(-enemy.width / 2, 0)
        ctx.lineTo(-enemy.width / 3, -enemy.height / 2)
        ctx.lineTo(0, -enemy.height / 3)
        ctx.lineTo(enemy.width / 3, -enemy.height / 2)
        ctx.lineTo(enemy.width / 2, 0)
        ctx.closePath()
        ctx.fill()
        // Cockpit
        ctx.fillStyle = '#fbbf24'
        ctx.beginPath()
        ctx.arc(0, 0, 4, 0, Math.PI * 2)
        ctx.fill()
        // Wing tips
        ctx.fillStyle = enemy.color
        ctx.beginPath()
        ctx.arc(-enemy.width / 2, 0, 3, 0, Math.PI * 2)
        ctx.fill()
        ctx.beginPath()
        ctx.arc(enemy.width / 2, 0, 3, 0, Math.PI * 2)
        ctx.fill()
      } else {
        // Heavy battleship
        const hGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, enemy.width / 2)
        hGrad.addColorStop(0, '#4b5563')
        hGrad.addColorStop(0.7, enemy.color)
        hGrad.addColorStop(1, '#1f2937')
        ctx.fillStyle = hGrad
        ctx.beginPath()
        for (let v = 0; v < 6; v++) {
          const angle = (Math.PI * 2 * v) / 6 - Math.PI / 2
          const px = Math.cos(angle) * enemy.width / 2
          const py = Math.sin(angle) * enemy.height / 2
          if (v === 0) ctx.moveTo(px, py)
          else ctx.lineTo(px, py)
        }
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#9ca3af'
        ctx.lineWidth = 1.5
        ctx.stroke()
        // Core reactor
        const coreGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 8)
        coreGrad.addColorStop(0, '#fef3c7')
        coreGrad.addColorStop(0.5, '#fbbf24')
        coreGrad.addColorStop(1, '#92400e')
        ctx.fillStyle = coreGrad
        ctx.beginPath()
        ctx.arc(0, 0, 8, 0, Math.PI * 2)
        ctx.fill()
        // Cannons
        ctx.fillStyle = '#6b7280'
        ctx.fillRect(-enemy.width / 2 - 5, -3, 5, 6)
        ctx.fillRect(enemy.width / 2, -3, 5, 6)
      }
      ctx.restore()
      ctx.shadowBlur = 0

      // HP bar
      const hpW = enemy.width + 10
      const hpH = 4
      const hpX = enemy.x - hpW / 2
      const hpY = enemy.y - enemy.height / 2 - 12
      const hpPct = enemy.hp / enemy.maxHp
      ctx.fillStyle = '#1f2937'
      ctx.fillRect(hpX, hpY, hpW, hpH)
      ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : hpPct > 0.25 ? '#eab308' : '#ef4444'
      ctx.fillRect(hpX, hpY, hpW * hpPct, hpH)

      // Bullet-enemy collision
      for (let b = bullets.length - 1; b >= 0; b--) {
        const bdx = bullets[b].x - enemy.x
        const bdy = bullets[b].y - enemy.y
        if (Math.abs(bdx) < enemy.width / 2 + 5 && Math.abs(bdy) < enemy.height / 2 + 5) {
          bullets.splice(b, 1)
          enemy.hp--
          game.particles.push(...createParticles(enemy.x, enemy.y, enemy.color, 5))
          if (enemy.hp <= 0) {
            game.particles.push(...createParticles(enemy.x, enemy.y, enemy.color, 20))
            game.particles.push(...createParticles(enemy.x, enemy.y, '#fbbf24', 10))
            game.score += enemy.points * (game.combo + 1)
            game.combo++
            game.comboTimer = 120
            setScore(game.score)
            setCombo(game.combo)
            game.screenShake = 8
            if (game.score > game.level * 500) { game.level++; setLevel(game.level) }
            enemies.splice(i, 1)
            break
          }
        }
      }
    }

    // === ENEMY BULLETS ===
    for (let i = game.enemyBullets.length - 1; i >= 0; i--) {
      const eb = game.enemyBullets[i]
      eb.x += eb.vx
      eb.y += eb.vy
      if (eb.x < -10 || eb.x > canvas.width + 10 || eb.y < -10 || eb.y > canvas.height + 10) {
        game.enemyBullets.splice(i, 1); continue
      }
      // Plasma bullet
      ctx.shadowColor = '#ef4444'
      ctx.shadowBlur = 10
      const ebGrad = ctx.createRadialGradient(eb.x, eb.y, 0, eb.x, eb.y, 5)
      ebGrad.addColorStop(0, '#fef2f2')
      ebGrad.addColorStop(0.4, '#ef4444')
      ebGrad.addColorStop(1, 'rgba(239, 68, 68, 0)')
      ctx.fillStyle = ebGrad
      ctx.beginPath()
      ctx.arc(eb.x, eb.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.shadowBlur = 0
      // Collision with player
      const pdx = eb.x - player.x
      const pdy = eb.y - player.y
      if (Math.sqrt(pdx * pdx + pdy * pdy) < 18 && game.invincible <= 0) {
        game.enemyBullets.splice(i, 1)
        if (player.shield) {
          player.shield = false; setPowerUp(null)
          game.particles.push(...createParticles(player.x, player.y, '#60a5fa', 15))
          game.screenShake = 5
        } else {
          game.lives--; setLives(game.lives)
          game.screenShake = 15; game.invincible = 120
          game.combo = 0; setCombo(0)
          game.particles.push(...createParticles(player.x, player.y, '#ef4444', 25))
          if (game.lives <= 0) {
            if (game.score > highScore) { setHighScore(game.score); localStorage.setItem('spaceHighScore', game.score.toString()) }
            setGameState('gameover'); return
          }
        }
      }
    }

    // === ASTEROIDS ===
    for (let i = asteroids.length - 1; i >= 0; i--) {
      asteroids[i].y += asteroids[i].speed
      asteroids[i].rotation += asteroids[i].rotationSpeed
      if (asteroids[i].y > canvas.height + asteroids[i].size * 2) {
        asteroids.splice(i, 1); game.combo = 0; setCombo(0); continue
      }
      ctx.save()
      ctx.translate(asteroids[i].x, asteroids[i].y)
      ctx.rotate(asteroids[i].rotation)
      const astGrad = ctx.createRadialGradient(-asteroids[i].size * 0.2, -asteroids[i].size * 0.2, 0, 0, 0, asteroids[i].size)
      astGrad.addColorStop(0, asteroids[i].color1)
      astGrad.addColorStop(1, asteroids[i].color2)
      ctx.fillStyle = astGrad
      ctx.strokeStyle = 'rgba(156, 163, 175, 0.5)'
      ctx.lineWidth = 1
      ctx.beginPath()
      const numV = asteroids[i].vertices.length
      for (let j = 0; j < numV; j++) {
        const angle = (Math.PI * 2 * j) / numV
        const r = asteroids[i].vertices[j]
        if (j === 0) ctx.moveTo(Math.cos(angle) * r, Math.sin(angle) * r)
        else ctx.lineTo(Math.cos(angle) * r, Math.sin(angle) * r)
      }
      ctx.closePath()
      ctx.fill()
      ctx.stroke()
      // Craters on asteroid
      ctx.fillStyle = 'rgba(0,0,0,0.2)'
      ctx.beginPath()
      ctx.arc(asteroids[i].size * 0.2, asteroids[i].size * 0.1, asteroids[i].size * 0.15, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(-asteroids[i].size * 0.3, -asteroids[i].size * 0.2, asteroids[i].size * 0.1, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()

      // Bullet-asteroid
      for (let b = bullets.length - 1; b >= 0; b--) {
        const bdx = bullets[b].x - asteroids[i].x
        const bdy = bullets[b].y - asteroids[i].y
        if (Math.sqrt(bdx * bdx + bdy * bdy) < asteroids[i].size) {
          bullets.splice(b, 1)
          game.particles.push(...createParticles(asteroids[i].x, asteroids[i].y, '#f97316', 12))
          if (asteroids[i].size > 25) {
            for (let k = 0; k < 2; k++) {
              const ns = asteroids[i].size * 0.6
              const verts: number[] = []
              const nv = Math.floor(Math.random() * 3) + 5
              for (let v = 0; v < nv; v++) verts.push(ns * (0.7 + Math.random() * 0.6))
              asteroids.push({
                x: asteroids[i].x + (Math.random() - 0.5) * 20,
                y: asteroids[i].y, size: ns,
                speed: asteroids[i].speed * 1.2,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.08,
                vertices: verts,
                color1: asteroids[i].color1,
                color2: asteroids[i].color2,
              })
            }
          }
          asteroids.splice(i, 1)
          game.combo++; game.comboTimer = 120
          game.score += 10 * game.combo
          setScore(game.score); setCombo(game.combo)
          if (game.score > game.level * 500) { game.level++; setLevel(game.level) }
          break
        }
      }

      // Player-asteroid
      if (i < asteroids.length) {
        const adx = asteroids[i].x - player.x
        const ady = asteroids[i].y - player.y
        if (Math.sqrt(adx * adx + ady * ady) < asteroids[i].size + 15 && game.invincible <= 0) {
          if (player.shield) {
            player.shield = false; setPowerUp(null)
            asteroids.splice(i, 1)
            game.particles.push(...createParticles(player.x, player.y, '#60a5fa', 20))
            game.screenShake = 5
          } else {
            game.lives--; setLives(game.lives)
            game.screenShake = 15; game.invincible = 120
            game.combo = 0; setCombo(0)
            game.particles.push(...createParticles(player.x, player.y, '#ef4444', 25))
            asteroids.splice(i, 1)
            if (game.lives <= 0) {
              if (game.score > highScore) { setHighScore(game.score); localStorage.setItem('spaceHighScore', game.score.toString()) }
              setGameState('gameover'); return
            }
          }
        }
      }
    }

    // Combo timer
    if (game.comboTimer > 0) { game.comboTimer--; if (game.comboTimer <= 0) { game.combo = 0; setCombo(0) } }
    if (game.invincible > 0) game.invincible--

    // === PARTICLES ===
    for (let i = particles.length - 1; i >= 0; i--) {
      particles[i].x += particles[i].vx
      particles[i].y += particles[i].vy
      particles[i].vx *= 0.96
      particles[i].vy *= 0.96
      particles[i].life -= 0.02
      if (particles[i].life <= 0) { particles.splice(i, 1); continue }
      ctx.globalAlpha = particles[i].life
      ctx.fillStyle = particles[i].color
      ctx.beginPath()
      ctx.arc(particles[i].x, particles[i].y, particles[i].size * particles[i].life, 0, Math.PI * 2)
      ctx.fill()
      ctx.globalAlpha = 1
    }

    if (game.screenShake > 0) ctx.restore()

    game.animationId = requestAnimationFrame(gameLoop)
  }, [shoot, createAsteroid, createEnemy, createParticles, highScore])

  // Canvas resize
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      gameRef.current.stars = initStars(canvas.width, canvas.height)
      gameRef.current.player.x = canvas.width / 2
      gameRef.current.player.y = canvas.height - 80
    }
    resize()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [initStars])

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return
    gameRef.current.animationId = requestAnimationFrame(gameLoop)
    return () => cancelAnimationFrame(gameRef.current.animationId)
  }, [gameState, gameLoop])

  // Key handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase()
      gameRef.current.keys[key] = true
      setPressedKeys(prev => new Set(prev).add(key))
      if (e.key === ' ') e.preventDefault()
    }
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase()
      gameRef.current.keys[key] = false
      setPressedKeys(prev => { const n = new Set(prev); n.delete(key); return n })
    }
    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('keyup', handleKeyUp)
    return () => { window.removeEventListener('keydown', handleKeyDown); window.removeEventListener('keyup', handleKeyUp) }
  }, [])

  // Mouse — LMB shoot
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0 && gameState === 'playing') shoot()
    }
    const handleContextMenu = (e: Event) => e.preventDefault()
    canvas.addEventListener('mousedown', handleMouseDown)
    canvas.addEventListener('contextmenu', handleContextMenu)
    return () => { canvas.removeEventListener('mousedown', handleMouseDown); canvas.removeEventListener('contextmenu', handleContextMenu) }
  }, [gameState, shoot])

  // Touch
  const touchRef = useRef<{ startX: number; startY: number; currentX: number; currentY: number } | null>(null)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const handleTouchStart = (e: TouchEvent) => {
      e.preventDefault()
      const touch = e.touches[0]
      touchRef.current = { startX: touch.clientX, startY: touch.clientY, currentX: touch.clientX, currentY: touch.clientY }
      const rect = canvas.getBoundingClientRect()
      gameRef.current.player.x = touch.clientX - rect.left
      gameRef.current.player.y = touch.clientY - rect.top
      shoot()
    }
    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault()
      if (!touchRef.current) return
      const touch = e.touches[0]
      const rect = canvas.getBoundingClientRect()
      gameRef.current.player.x = touch.clientX - rect.left
      gameRef.current.player.y = touch.clientY - rect.top
      touchRef.current.currentX = touch.clientX
      touchRef.current.currentY = touch.clientY
    }
    const handleTouchEnd = () => { touchRef.current = null }
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false })
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false })
    canvas.addEventListener('touchend', handleTouchEnd)
    return () => {
      canvas.removeEventListener('touchstart', handleTouchStart)
      canvas.removeEventListener('touchmove', handleTouchMove)
      canvas.removeEventListener('touchend', handleTouchEnd)
    }
  }, [shoot])

  // Animated background for menu
  useEffect(() => {
    if (gameState === 'playing') return
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return
    let menuStars = initStars(canvas.width, canvas.height)
    let animId = 0
    let t = 0
    const menuLoop = () => {
      t++
      const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height)
      bgGrad.addColorStop(0, '#050510')
      bgGrad.addColorStop(0.7, '#0a0a2a')
      bgGrad.addColorStop(1, '#1a1a4a')
      ctx.fillStyle = bgGrad
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      menuStars.forEach(s => {
        s.y += s.speed * 0.5
        s.twinkle += 0.02
        if (s.y > canvas.height) { s.y = 0; s.x = Math.random() * canvas.width }
        ctx.beginPath()
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255,255,255,${s.opacity * (0.7 + Math.sin(s.twinkle) * 0.3)})`
        ctx.fill()
      })
      // Earth at bottom
      const earthR = 400
      const earthGrad = ctx.createRadialGradient(canvas.width / 2, canvas.height + earthR - 100, earthR * 0.3, canvas.width / 2, canvas.height + earthR - 100, earthR)
      earthGrad.addColorStop(0, '#4a9eff')
      earthGrad.addColorStop(0.5, '#2563eb')
      earthGrad.addColorStop(1, '#0c2d6b')
      ctx.fillStyle = earthGrad
      ctx.beginPath()
      ctx.arc(canvas.width / 2, canvas.height + earthR - 100, earthR, 0, Math.PI * 2)
      ctx.fill()
      // Moon at top
      const moonR = 150
      const moonGrad = ctx.createRadialGradient(canvas.width / 2 - 30, 100, moonR * 0.1, canvas.width / 2, 120, moonR)
      moonGrad.addColorStop(0, '#e5e5e5')
      moonGrad.addColorStop(0.7, '#b0b0b0')
      moonGrad.addColorStop(1, '#707070')
      ctx.fillStyle = moonGrad
      ctx.beginPath()
      ctx.arc(canvas.width / 2, 120, moonR, 0, Math.PI * 2)
      ctx.fill()
      animId = requestAnimationFrame(menuLoop)
    }
    animId = requestAnimationFrame(menuLoop)
    return () => cancelAnimationFrame(animId)
  }, [gameState, initStars])

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0a0a1a]">
      <canvas ref={canvasRef} className="absolute inset-0" />

      {/* HUD */}
      {gameState === 'playing' && (
        <>
          {/* Distance to Moon progress bar */}
          <div className="absolute top-16 left-1/2 -translate-x-1/2 w-64 md:w-80 pointer-events-none z-10">
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>🌍 Земля</span>
              <span className="text-purple-300 font-bold">{distance}%</span>
              <span>🌙 Луна</span>
            </div>
            <div className="h-3 bg-white/10 rounded-full overflow-hidden backdrop-blur-sm border border-white/10">
              <div
                className="h-full rounded-full transition-all duration-300 bg-gradient-to-r from-blue-500 via-purple-500 to-gray-400"
                style={{ width: `${distance}%` }}
              />
            </div>
          </div>

          <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start pointer-events-none z-10">
            <div className="flex flex-col gap-1">
              <div className="text-white font-bold text-lg">Очки: <span className="text-yellow-400">{score}</span></div>
              <div className="text-gray-400 text-sm">Уровень: <span className="text-purple-400">{level}</span></div>
              {combo > 1 && <div className="text-orange-400 font-bold animate-pulse">Комбо x{combo}! 🔥</div>}
            </div>
            <div className="flex flex-col items-end gap-1">
              <div className="flex gap-1">
                {Array.from({ length: 3 }).map((_, i) => (
                  <span key={i} className={`text-xl ${i < lives ? 'opacity-100' : 'opacity-20'}`}>❤️</span>
                ))}
              </div>
              {powerUp && (
                <div className="text-sm px-2 py-1 rounded bg-white/10 backdrop-blur-sm text-green-400">
                  {powerUp === 'shield' && '🛡️ Щит'}
                  {powerUp === 'rapid' && '⚡ Скорость'}
                  {powerUp === 'multi' && '✦ Мульти'}
                </div>
              )}
            </div>
          </div>

          {/* WASD indicator */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 pointer-events-none z-10 flex flex-col items-center gap-1 opacity-60">
            <div className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center font-bold text-sm ${pressedKeys.has('w') || pressedKeys.has('arrowup') ? 'bg-purple-500 border-purple-400 text-white' : 'bg-white/10 border-white/30 text-gray-400'}`}>W</div>
            <div className="flex gap-1">
              <div className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center font-bold text-sm ${pressedKeys.has('a') || pressedKeys.has('arrowleft') ? 'bg-purple-500 border-purple-400 text-white' : 'bg-white/10 border-white/30 text-gray-400'}`}>A</div>
              <div className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center font-bold text-sm ${pressedKeys.has('s') || pressedKeys.has('arrowdown') ? 'bg-purple-500 border-purple-400 text-white' : 'bg-white/10 border-white/30 text-gray-400'}`}>S</div>
              <div className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center font-bold text-sm ${pressedKeys.has('d') || pressedKeys.has('arrowright') ? 'bg-purple-500 border-purple-400 text-white' : 'bg-white/10 border-white/30 text-gray-400'}`}>D</div>
            </div>
          </div>
        </>
      )}

      {/* Menu */}
      {gameState === 'menu' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
          <div className="text-center px-4">
            <div className="text-6xl mb-4 animate-bounce">🚀</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-2 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              Космический Защитник
            </h1>
            <p className="text-lg text-gray-300 mb-2">Миссия: долететь до Луны!</p>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              Пролети через астероиды, уничтожь врагов и доберись до Луны! 🌙
            </p>
            <button onClick={startGame} className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl text-white font-bold text-xl hover:scale-105 transition-transform shadow-lg shadow-purple-500/30 active:scale-95">
              🎮 Начать миссию
            </button>
            <div className="mt-8 text-gray-500 text-sm space-y-1">
              <p>⌨️ WASD / Стрелки — движение</p>
              <p>🖱️ ЛКМ — стрельба</p>
              <p>📱 Мобильные — касание</p>
            </div>
            {highScore > 0 && <div className="mt-6 text-yellow-400 font-semibold">🏆 Рекорд: {highScore}</div>}
          </div>
        </div>
      )}

      {/* Game Over */}
      {gameState === 'gameover' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/70 backdrop-blur-sm">
          <div className="text-center px-4">
            <div className="text-5xl mb-4">💥</div>
            <h2 className="text-3xl md:text-5xl font-bold mb-4 text-red-400">Миссия провалена!</h2>
            <p className="text-xl text-gray-400 mb-2">Прогресс до Луны: {distance}%</p>
            <p className="text-2xl text-white mb-2">Очки: <span className="text-yellow-400 font-bold">{score}</span></p>
            <p className="text-lg text-gray-400 mb-2">Уровень: <span className="text-purple-400">{level}</span></p>
            {score >= highScore && score > 0 && <p className="text-lg text-yellow-400 mb-4 animate-pulse">🎉 Новый рекорд!</p>}
            <p className="text-gray-500 mb-8">Лучший результат: {highScore}</p>
            <button onClick={startGame} className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl text-white font-bold text-xl hover:scale-105 transition-transform shadow-lg shadow-purple-500/30 active:scale-95">
              🔄 Попробовать снова
            </button>
          </div>
        </div>
      )}

      {/* Win! */}
      {gameState === 'win' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/60 backdrop-blur-sm">
          <div className="text-center px-4">
            <div className="text-7xl mb-4 animate-bounce">🌙</div>
            <h2 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-yellow-300 via-white to-yellow-300 bg-clip-text text-transparent">
              Посадка на Луну!
            </h2>
            <p className="text-xl text-gray-300 mb-6">Миссия выполнена! Вы долетели до Луны! 🎉</p>
            <p className="text-2xl text-white mb-2">Очки: <span className="text-yellow-400 font-bold">{score}</span></p>
            <p className="text-lg text-gray-400 mb-2">Уровень: <span className="text-purple-400">{level}</span></p>
            {score >= highScore && <p className="text-lg text-yellow-400 mb-4 animate-pulse">🏆 Новый рекорд!</p>}
            <p className="text-gray-500 mb-8">Лучший результат: {highScore}</p>
            <button onClick={startGame} className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl text-white font-bold text-xl hover:scale-105 transition-transform shadow-lg shadow-yellow-500/30 active:scale-95">
              🚀 Новая миссия
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
